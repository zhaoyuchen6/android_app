# ab-manager-communication-iframe

父页面与iframe之间传递消息。

1.引入
```js
import { CommunicationIframe } from 'ab-manager-communication-iframe'
```

2.父页面向子页面发送消息：
```js
CommunicationIframe.sendMessage(iframeName, msg);
```

例：

```html
<template>
    <iframe name="T10001" ></iframe>
</template>
```
```js
<script>
    CommunicationIframe.sendMessage('T10001', '向T10001发送的消息');
</script>
```

> 注：切换交易存在焦点重置问题，由父元素向指定交易iframe发送消息重置焦点，传递的参数必须为`reset`。

```
CommunicationIframe.sendMessage(iframeName, "reset");
```

3.子页面向父页面发送消息：
```js
CommunicationIframe.popupMessage(msg);
```

> 由于只有一个父元素，所以不用指定`name`，直接传递数据(msg)即可。

| 参数     | 类型 | 说明 |
| -------- | --- | --- |
| iframeName | string | 发送消息的iframe的name |
| msg | - | 发送的消息 |